//
// template-rt.cpp
//

#define _CRT_SECURE_NO_WARNINGS
#include "matm.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <math.h>
#include <algorithm>
using namespace std;

// -------------------------------------------------------------------
// Ray struct

struct Ray
{
    vec3 origin;		// origin of the ray
    vec3 dir;			// direction of the ray
};


// -------------------------------------------------------------------
// Sphere struct

struct Sphere
{	
	vec3 center;
	float radius;		
	vec3 ka, kd, ks;	// ambient, diffuse and specular reflecction constant in Phong's reflection model
	vec3 reflectivity;	// control how much light is received from reflection in recursive ray-tracing (e.g. 0.1)
	float alpha;		// control size of specular highlight (e.g. 20)

	// default constructor
	Sphere(const vec3& ic=vec3(0.0f), const float& ir=0.0f, const vec3& ika=vec3(0.0f), const vec3& ikd=vec3(0.0f), const vec3& iks=vec3(0.0f), const float& ireflectivity=0.1f, const float& ialpha=1.0f):
	center(ic), radius(ir), ka(ika), kd(ikd), ks(iks), reflectivity(ireflectivity), alpha(ialpha)
	{}

	bool intersect(const Ray& ray, float& t0, float& t1);
};


// return true if the input ray intersects with the sphere; otherwise return false
// return by reference the intersections. t0 refers to closer intersection, t1 refers to farther intersection
bool Sphere::intersect(const Ray& ray, float& t0, float& t1)
{
	float r = this->radius;
	vec3 center = this->center;
	vec3 origin = ray.origin;
	vec3 direction = ray.dir;
	vec3 delta = direction - origin;

	float a, b, c;
	float discrimenant;

	//a = (dx * dx) + (dy * dy) + (dz * dz);
	a = dot(delta, delta);
	//b = (2 * dx*(x0 - cx)) + (2 * dy*(y0 - cy)) + (2 * dz*(z0 - cz));
	b = 2 * dot(delta, origin - center);
	//c = (((x0 - cx) * (x0 - cx)) + ((y0 - cy) * (y0 - cy)) + ((z0 - cz) * (z0 - cz))) - (r*r);
	c = dot(origin - center, origin - center) - (r*r);

	discrimenant = (b*b) - (4*(a*c));

	if (discrimenant == 0) {
		return true; //tangent to sphere
	}
	else if (discrimenant > 0) {
		t0 = ((-b) - sqrt(discrimenant)) / (2 * a);
		t1 = ((-b) + sqrt(discrimenant)) / (2 * a);
		return true;
	}
	else {
		return false; // discrimenant < 0
	}
	
	


	
	//return false;		// this should be replaced by code to determine intersection with a sphere
};


// -------------------------------------------------------------------
// Light Structs

struct AmbientLight
{
	vec3 ia;		// ambient intensity (a vec3 of 0.0 to 1.0, each entry in vector refers to R,G,B channel)

	// default constructor
	AmbientLight(const vec3& iia=vec3(0.0f)):
	ia(iia)
	{}

};


struct PointLight
{
	vec3 location;	// location of point light
	vec3 id, is;	// diffuse intensity, specular intensity (vec3 of 0.0 to 1.0)
	
	// default constructor
	PointLight(const vec3& iloc=vec3(0.0f), const vec3& iid=vec3(0.0f), const vec3& iis=vec3(0.0f)):
	location(iloc), id(iid), is(iis)
	{}

};


// -------------------------------------------------------------------
// Our Scene

// lights and spheres in our scene
AmbientLight my_ambient_light;			// our ambient light
vector<PointLight> my_point_lights;		// a vector containing all our point lights
vector<Sphere> my_spheres;				// a vector containing all our spheres


// this stores the color of each pixel, which will take the ray-tracing results
vector<vec3> g_colors;	

int recursion_lvl_max = 2;

// this defines the screen
int g_width = 640;				//number of pixels
int g_height = 480;				// "g_" refers to coord in 2D image space
float fov = 30;					// field of view (in degree)

float invWidth = 1 / float(g_width);
float invHeight = 1 / float(g_height);
float aspectratio = g_width / float(g_height);
float angle = tan(M_PI * 0.5 * fov / float(180));


// -------------------------------------------------------------------
// Utilities

void setColor(int ix, int iy, const vec3& color)
{
    int iy2 = g_height - iy - 1; // Invert iy coordinate.
    g_colors[iy2 * g_width + ix] = color;
}


vec3 getDir(int ix, int iy)
{
	// This should return the direction from the origin
	// to pixel (ix, iy), normalized!

	vec3 dir;
	dir.x = (2 * ((ix + 0.5) * invWidth) - 1) * angle * aspectratio;
	dir.y = (2 * ((iy + 0.5) * invHeight) - 1) * angle;
	dir.z = -1;

	return dir;
}



// -------------------------------------------------------------------
// Ray tracing

vec3 trace(const Ray& ray, int recursion_lvl)
{
	float inf = 99999;
	float t_min = inf;
	int near_sphere_idx;
	bool has_intersection = false;

	for (int i=0; i<my_spheres.size(); ++i)
	{
		float t0 = inf;		//some large value
		float t1 = inf;

		// check intersection with sphere
		if (my_spheres[i].intersect(ray, t0, t1))
		{
			has_intersection = true;

			if (t0<t_min)
			{
				t_min = t0;
				near_sphere_idx = i;
			}
		}	
	}

	if (has_intersection == false)
		// just return background color (black)
	    return vec3(0.0f, 0.0f, 0.0f);

	Sphere my_sphere = my_spheres[near_sphere_idx];


	//implement Phong's relection model
	float r = 0, g = 0, b = 0, x, y, z, dx, dy, dz, distance, NLmax, NHmax, VRmax;
	float Nx, Ny, Nz, Lx = 0, Ly = 0, Lz = 0;
	vec3 Normal, Lprime, L, V, H, R, Id, Is;
	vector<vec3> Lightrays;
	vector<Ray> Reflectrays;
	Ray Reflected, Light;
	dx = ray.dir.x - ray.origin.x;
	dy = ray.dir.y - ray.origin.y;
	dz = ray.dir.z - ray.origin.z;
	x = ray.origin.x + (t_min * dx);
	y = ray.origin.y + (t_min * dy);
	z = ray.origin.z + (t_min * dz);
	vec3 pHit(x, y, z);

	V = normalize(-ray.dir); //view vector

	Nx = (x - my_sphere.center.x) / my_sphere.radius;
	Ny = (y - my_sphere.center.y) / my_sphere.radius;
	Nz = (z - my_sphere.center.z) / my_sphere.radius;
	Normal = { Nx, Ny, Nz };
	Normal = normalize(Normal); //Normal vector

	for (int i = 0; i < my_point_lights.size(); i++) {
		Lx = my_point_lights[i].location.x - x;
		Ly = my_point_lights[i].location.y - y;
		Lz = my_point_lights[i].location.z - z;
		Lprime = { Lx, Ly, Lz };
		L = normalize(Lprime);
		Lightrays.push_back(L);
	}

	vec3 color(r,g,b);	// this code should be replaced by codes of the Phong's reflection model (i.e. color should be determined by Phong's model)

	color += (my_sphere.ka * my_ambient_light.ia); //First step of Phong's model *Ambient*

	//Summation formula for Phong's refelection model
	for (int i = 0; i < Lightrays.size(); i++) {
		NLmax = max(0.0f, dot(Normal, Lightrays[i])); //a Diffuse component
		distance = length(Lightrays[i]); //length of light ray
		//Intensity
		Id = my_point_lights[i].id;
		Is = my_point_lights[i].is;
		// min(1, F(d)i * Ii)
		Id *= min(1.0f, 1 / (distance * distance)); 
		Is *= min(1.0f, 1 / (distance * distance)); 
		//H = normalize(Lightrays[i] + V); //approximation of R to save computation time
		R = normalize(2 * Normal*(dot(Lightrays[i], Normal)) - Lightrays[i]);
		//NHmax = max(0.0f, dot(Normal, H)); //a Specular component
		VRmax = max(0.0f, dot(V, R));
		color += (Id * my_sphere.kd * NLmax) + (Is * my_sphere.ks * pow(VRmax, 100.0f)); //second *Diffuse* and third *Specular* step of Phong's model
		Light.origin = Lightrays[i];
		Light.dir = getDir(Lightrays[i].x, Lightrays[i].y);
		//Checks if the light ray intersects with another sphere.  If it does then reduces the color by 50%
		for (int k = 0; k < my_spheres.size(); k++)
		{
			float t0 = inf;		//some large value
			float t1 = inf;

			// check intersection with spheres and makes sure it is not the same sphere
			if (my_spheres[k].intersect(Light, t0, t1) && k != near_sphere_idx)
			{
				color /= 2; //Reduces color by 50% making the shadow
			}
		}
		Reflected.origin = R;
		Reflected.dir = getDir(R.x, R.y);
		Reflectrays.push_back(Reflected);
	}




	if (recursion_lvl > 0)
	{
		// TODO: implement recursive ray-tracing here, to add contribution of light reflected from other objects
		recursion_lvl--;

		for (int i = 0; i < Reflectrays.size(); i++) {
			for (int k = 0; k < my_spheres.size(); k++)
			{
				float t0 = inf;		//some large value
				float t1 = inf;

				// check intersection with spheres and makes sure it is not the same sphere
				if (my_spheres[k].intersect(Reflectrays[i], t0, t1) && k != near_sphere_idx)
				{
					distance = length(Lightrays[i]) + length(Reflectrays[i].origin);
					color += trace(Reflectrays[i], recursion_lvl) * (1 / (distance * distance));
				}
			}
		}
	}
	return color; //if recursion level is over 2 then just returns the color			
}




void renderPixel(int ix, int iy)
{
    Ray ray;
    ray.origin = vec3(0.0f, 0.0f, 0.0f);
    ray.dir = getDir(ix, iy);
    vec3 color = trace(ray, recursion_lvl_max);
    setColor(ix, iy, color);
}

void render()
{
    for (int iy = 0; iy < g_height; iy++)
        for (int ix = 0; ix < g_width; ix++)
            renderPixel(ix, iy);
}


// -------------------------------------------------------------------
// PPM saving

void savePPM(int Width, int Height, char* fname, unsigned char* pixels) 
{
    FILE *fp;
    const int maxVal=255;

    printf("Saving image %s: %d x %d\n", fname, Width, Height);
    fp = fopen(fname,"wb");
    if (!fp) {
        printf("Unable to open file '%s'\n", fname);
        return;
    }
    fprintf(fp, "P6\n");
    fprintf(fp, "%d %d\n", Width, Height);
    fprintf(fp, "%d\n", maxVal);

    for(int j = 0; j < Height; j++) {
        fwrite(&pixels[j*Width*3], 3, Width, fp);
    }

    fclose(fp);
}

void saveFile()
{
    // Convert color components from floats to unsigned chars.
    // clamp values if out of range.
    unsigned char* buf = new unsigned char[g_width * g_height * 3];
    for (int y = 0; y < g_height; y++)
        for (int x = 0; x < g_width; x++)
            for (int i = 0; i < 3; i++)
                buf[y*g_width*3+x*3+i] = (unsigned char)(((float*)g_colors[y*g_width+x])[i] * 255.9f);
    
    // change file name based on input file name.
    savePPM(g_width, g_height, "output.ppm", buf);
    delete[] buf;
}


// -------------------------------------------------------------------
// Main

int main(int argc, char* argv[])
{
	// setup pixel array
    g_colors.resize(g_width * g_height);

	// setup our scene...

	// setup ambient light
	my_ambient_light = AmbientLight(vec3(0.1));

	// setup point lights
	my_point_lights.push_back(
								PointLight(vec3(3,3,0), vec3(0.5, 0.5, 0.5), vec3(0.5,0.5,0.5))
								);

	my_point_lights.push_back(
								PointLight(vec3(-3,-3,0), vec3(0.1, 0.1, 0.1), vec3(0.1,0.1,0.1))
								);

	// setup spheres
	my_spheres.push_back(
							Sphere(vec3(0,0,-10), 1.0, vec3(0.1,0.1,0.1), vec3(0.5,0.5,0.5), vec3(0.5,0.5,0.5), 0.2, 100.0)
							);

	my_spheres.push_back(
							Sphere(vec3(-1.5,0.5,-8), 0.5, vec3(0.0,1.0,0.0), vec3(0.0,1.0,0.0), vec3(0.5,0.5,0.5), 0.0, 10.0)
							);

    render();
    saveFile();
	return 0;
}

