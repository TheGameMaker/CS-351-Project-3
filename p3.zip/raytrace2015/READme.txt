Clark Smiley [g-number: 00891966]
Project 3

Requirements Implemented:
- the function "intersect" under the Sphere struct to determine the intersection between a ray and the sphere
- the Phong's reflection model 
- recursive ray-tracing

Requirements Not Implemented:
- none

Extra Credits:
- Shadowing

Other Notes:
- I belive my reflected rays are wrong or I am adding the color in the wrong spot, and that is why when the recursion is called it draws two spheres
	instead of one in the correct location.
- I used a ns of 100.0 for the power of my specular component.
- I use 1/(d*d) as my distance attenuation or f(d).